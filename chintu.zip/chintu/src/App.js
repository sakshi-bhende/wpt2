import React, { useState, useEffect } from 'react';
import './App.css';


const App = () => {
  const [users, setUsers] = useState([]);
  const [userData, setUserData] = useState({
    firstName: '',
    lastName: '',
    email: '',
  });
  const [currentUser, setCurrentUser] = useState(null);

  // Load users from localStorage on component mount
  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
    setUsers(storedUsers);
  }, []);

  // Save users to localStorage whenever users state changes
  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  const handleInputChange = (e) => {
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (currentUser) {
      // Editing existing user
      setUsers(
        users.map((user) =>
          user.email === currentUser.email ? userData : user
        )
      );
      setCurrentUser(null);
    } else {
      // Adding a new user
      setUsers([...users, userData]);
    }

    setUserData({
      firstName: '',
      lastName: '',
      email: '',
    });
  };

  const handleEdit = (user) => {
    setUserData(user);
    setCurrentUser(user);
  };

  const handleDelete = (email) => {
    setUsers(users.filter((user) => user.email !== email));
  };

  return (
    <div>
      <h1>User Management</h1>

      {/* User Form for adding or editing a user */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="firstName"
          value={userData.firstName}
          onChange={handleInputChange}
          placeholder="First Name"
          required
        />
        <input
          type="text"
          name="lastName"
          value={userData.lastName}
          onChange={handleInputChange}
          placeholder="Last Name"
          required
        />
        <input
          type="email"
          name="email"
          value={userData.email}
          onChange={handleInputChange}
          placeholder="Email"
          required
        />
        <button type="submit">{currentUser ? 'Update User' : 'Add User'}</button>
      </form>

      {/* User List */}
      <ul>
        {users.map((user, index) => (
          <li key={index}>
            {user.firstName} {user.lastName} - {user.email}
            <button onClick={() => handleEdit(user)}>Edit</button>
            <button onClick={() => handleDelete(user.email)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
