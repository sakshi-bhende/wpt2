import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Form = () => {
    const[name,setName] = useState('');
    const[address,setAddress] = useState('');
    
    function saveData(){
        const data = {name,address};
       axios.post("http://localhost:7745/api/data",data)
       .then((res)=>{
        alert("Data Added Successfully")
        setAddress('');
        setName('');
       })
       .catch((err)=>{
        alert("Not able to add data")
       })
        // console.log(name,address);
    }
  return (
    <div><h1>Add data</h1>
        <form action={()=>saveData()}>
        <label htmlFor='name' > Name</label>
        <input type='text' name='name' value={name} onChange={(e)=>setName(e.target.value)} required/>
        <label htmlFor='address'> Address</label>
        <input type='text' name='address' value={address} onChange={(e)=>setAddress(e.target.value)} required/>
        <button type='submit'>Submit</button>
        </form>
       
    </div>
  )
}

export default Form