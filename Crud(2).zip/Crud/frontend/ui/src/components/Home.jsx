import React from 'react'
import Form from './Form'
import DisplayData from './DisplayData'
import DeleteData from './DeleteData'
import UpdateData from './UpdateData'
import Header from './Header'

const Home = () => {
  return (
    <div>
      <Header/>
        <Form/><hr/>
        <DisplayData/>
    </div>
  )
}

export default Home