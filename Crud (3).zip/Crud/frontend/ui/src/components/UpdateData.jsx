import React, { useState } from 'react'
import axios from 'axios';
import Header from './Header';
import { useNavigate, useParams } from 'react-router-dom';
const UpdateData = () => {
    const {id} =useParams();
    const[name,setName] = useState('');
    const[address,setAddress] = useState('');
    const navigate = useNavigate();
    function updateData(){
        const data = {name,address};
       axios.put(`http://localhost:7745/api/data/${id}`,data)
       .then((res)=>{
        alert("Data updated Successfully")
        setAddress('');
        setName('');
        navigate('/');
       })
       .catch((err)=>{
        alert("Not able to update data")
       })
        console.log(id,name,address);
    }
  return (
    <div>
      <Header/>
      <h1>Update data</h1>
        <form action={()=>updateData()}>
        <label htmlFor='id' > Name</label>
        <input type='number' name='id' readOnly value={id} required/>
        <label htmlFor='name' > Name</label>
        <input type='text' name='name' value={name} onChange={(e)=>setName(e.target.value)} required/>
        <label htmlFor='address'> Address</label>
        <input type='text' name='address' value={address} onChange={(e)=>setAddress(e.target.value)} required/>
        <button type='submit'>Submit</button>
        </form>
       
    </div>
  )
}

export default UpdateData