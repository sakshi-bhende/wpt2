import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <div><Navbar expand="lg" className="bg-body-tertiary">
    <Container>
      <Navbar.Brand ><Link to="/" style={{color:"black", textDecoration:"none"}}>React-Bootstrap</Link></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="me-auto">
          <Link to="/home"  style={{color:"black", textDecoration:"none", alignContent:"center", padding:"2px" ,margin:"1px"}}>Home</Link>
          <Link to="/display" style={{color:"black", textDecoration:"none", alignContent:"center", padding:"2px" ,margin:"1px"}}>Display</Link>
          <Link to="/update/2" style={{color:"black", textDecoration:"none", alignContent:"center", padding:"2px" ,margin:"1px"}}>Update</Link>
          <Link to="/delete" style={{color:"black", textDecoration:"none", alignContent:"center", padding:"2px" ,margin:"1px"}}>Delete</Link>
          <NavDropdown title="Dropdown" id="basic-nav-dropdown">
            <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.2">
              Another action
            </NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item href="#action/3.4">
              Separated link
            </NavDropdown.Item>
          </NavDropdown>
        </Nav>
      </Navbar.Collapse>
    </Container>
  </Navbar></div>
  )
}

export default Header