import React, { useEffect, useState, useCallback } from 'react'
import Header from './Header';
import axios from "axios";
import Table from 'react-bootstrap/Table';
import { FaRegTrashAlt } from "react-icons/fa";
import { TiPencil } from "react-icons/ti";
import { useNavigate } from "react-router-dom";
const Main = () => {
    const[name,setName] = useState('');
    const[address,setAddress] = useState('');
    const [data, setData] = useState([]);
    const navigate = useNavigate();
  
    function saveData(){
        const data = {name,address};
       axios.post("http://localhost:7745/api/data",data)
       .then((res)=>{
        alert("Data Added Successfully")
        setAddress('');
        setName('');
       })
       .catch((err)=>{
        alert("Not able to add data")
       })
       
    }
    function deleteData(id){
        axios.delete(`http://localhost:7745/api/data/${id}`)
        .then((res)=>{
            alert("data deleted Successfully")
            fetchData();
        })
        .catch((err)=>{
            alert("Error in deleting data")
        })
    }
    const fetchData = useCallback(()=>{
        axios
        .get("http://localhost:7745/api/data")
        .then((res) => {
          setData(res.data);
        })
        .catch((err) => {
          console.error(err);
        });
      } ,[data]);
      
      useEffect(()=>{
        fetchData();
      },[data]);
  return (
    <div>
        <Header/>
        <h1>Add data</h1>
        <form action={()=>saveData()}>
        <label htmlFor='name' > Name</label>
        <input type='text' name='name' value={name} onChange={(e)=>setName(e.target.value)} required/>
        <label htmlFor='address'> Address</label>
        <input type='text' name='address' value={address} onChange={(e)=>setAddress(e.target.value)} required/>
        <button type='submit'>Submit</button>
        </form>
        <h2>Display Data</h2>
      <Table striped bordered hover style={{width:"50%",margin:"0 auto"}} >
        <thead>
            <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Address</th>
            <th>Edit</th>
            <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        {data.map((x) => (
          <tr key={x.id}>
             <td>{x.id}</td>
            <td>{x.name}</td>
            <td>{x.address}</td>
            <td> <TiPencil onClick={()=>{navigate(`/update/${x.id}`)}}/></td>  
            <td><FaRegTrashAlt onClick={()=>{deleteData(x.id)}}  /></td>    
          </tr>
        ))}
         </tbody>
      </Table>
    </div>
  )
}

export default Main