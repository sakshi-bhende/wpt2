import React, { useState } from 'react'
import axios from "axios";
import Header from './Header';
const DeleteData = () => {
    const[id,setId] = useState(0);
    function deleteData(){
        axios.delete(`http://localhost:7745/api/data/${id}`)
        .then((res)=>{
            alert("data deleted Successfully")
            setId('');
        })
        .catch((err)=>{
            alert("Error in deleting data")
        })
    }
  return (
    <div>
        <Header/>
        <h1>Delete by id</h1>
        <form action={()=>deleteData()}>
    <label htmlFor='id' > Name</label>
    <input type='number' name='id' value={id} onChange={(e)=>setId(e.target.value)} required/>
    
    <button type='submit'>Submit</button>
    </form>
    </div>
  )
}

export default DeleteData