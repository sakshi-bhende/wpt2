import React from 'react'
import Form from './Form'
import DisplayData from './DisplayData'
import DeleteData from './DeleteData'
import UpdateData from './UpdateData'
import Header from './Header'

const Home = () => {
  return (
    <div>
        <DisplayData/>
        <hr/>
        <Form/>
    </div>
  )
}

export default Home