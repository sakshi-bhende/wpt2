import React, { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import Table from "react-bootstrap/Table";
import { FaRegTrashAlt } from "react-icons/fa";
import { TiPencil } from "react-icons/ti";
import { useNavigate } from "react-router-dom";
import Header from "./Header";
const DisplayData = () => {
  const [data, setData] = useState([]);
  const navigate = useNavigate();
  function deleteData(id) {
    axios
      .delete(`http://localhost:7745/api/data/${id}`)
      .then((res) => {
        alert("data deleted Successfully");
        fetchData();
      })
      .catch((err) => {
        alert("Error in deleting data");
      });
  }

  const fetchData = useCallback(() => {
    axios
      .get("http://localhost:7745/api/data")
      .then((res) => {
        setData(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, [data]);

  useEffect(() => {
    fetchData();
  }, [data]);

  return (
    <div>
      <Header />
      <h2>Display Data</h2>
      <Table striped bordered hover style={{ width: "50%", margin: "0 auto" }}>
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Address</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {data.map((x) => (
            <tr key={x.id}>
              <td>{x.id}</td>
              <td>{x.name}</td>
              <td>{x.address}</td>
              <td>
                {" "}
                <TiPencil
                  onClick={() => {
                    navigate(`/update/${x.id}`);
                  }}
                />
              </td>
              <td>
                <FaRegTrashAlt
                  onClick={() => {
                    deleteData(x.id);
                  }}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};
export default DisplayData;
