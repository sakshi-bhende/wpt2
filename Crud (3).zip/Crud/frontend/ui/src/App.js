import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from './components/Header';
import UpdateData from './components/UpdateData';
import DisplayData from './components/DisplayData';
import DeleteData from './components/DeleteData';
import Main from './components/Main';
function App() {
  return (
    <div className="App">
      
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Main />}/>
        <Route path="/home" element={<Home />} lazy={<Home/>}/>
          <Route path="/update/:id" element={<UpdateData />} />
          <Route path="/display" element={<DisplayData />} />
          <Route path="/delete" element={<DeleteData />} />
          {/* <Route path="*" element={<NoPage />} /> */}
        
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
