const mysql = require("mysql2");

const db = mysql.createConnection({
    host:"localhost",
    user :"root",
    password:"cdac",
    database:"crud"
});
db.connect((err)=>{
    if(err){
        console.log("Not able to connect to database");
        return;
    }
    console.log("Successfully connecterd to database");
})

module.exports = db;