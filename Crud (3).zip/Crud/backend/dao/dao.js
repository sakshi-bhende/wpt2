const db = require("../dbConnection");

const getAllData=()=>{
    return new Promise((resolve,reject)=>{
        db.query("Select * from data",(err,result)=>{
            if(err){
                reject(err);
            }else{
                resolve(result);
            }
        });
    })
  
}
const getDataById=(id)=>{
    return new Promise((resolve,reject)=>{
        db.query(`Select * from data where id =${id}`,(err,result)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(result);
            }
        })
    })
}
const insertData=(data)=>{
    return new Promise((resolve, reject) => {
        const query = 'INSERT INTO data (name, address) VALUES (?, ?)';
        db.query(query, [data.name, data.address], (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
};

const updateData=(id,data)=>{
    return new Promise((resolve,reject)=>{
        const query = 'UPDATE data SET name = ?, address = ? WHERE id = ?';
        db.query(query,[data.name,data.address,id],(err,result)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(result);
            }
        })
    })
};
const deleteData=(id)=>{
    return new Promise((resolve,reject)=>{
        const query = 'Delete from data where id=?';
        db.query(query,[id],(err,result)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(result);
            }
        })
    })
}
module.exports={getAllData,insertData,updateData,getDataById,deleteData}