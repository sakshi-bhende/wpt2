const dao = require("../dao/dao");

const getAllData = (req,res)=>{
    dao.getAllData()
    .then((response)=>{
        res.json(response);
    })
    .catch((err)=>{
        res.status(500).json({ message: 'Error retrieving data' });
    })
}

const getDataById = (req,res)=>{
    dao.getDataById(req.params.id)
    .then((response)=>{
        res.status(200).json(response);
    })
    .catch((err)=>{
        res.status(500).json({ message: 'Error retrieving data' });
    })
}
const insertData = (req,res)=>{
    const name = req.body.name;
    const address = req.body.address;
    const data = {name,address};
    dao.insertData(data)
    .then((response)=>{
        res.status(201).json({message:"Data added Successfully"});
    })
    .catch((err)=>{
        res.status(500).json({ message: err});
    })
}
const deleteData =(req,res)=>{
    dao.deleteData(req.params.id)
    .then((response)=>{
        res.status(200).json({message:"Data Deleted Successfully"});
    })
    .catch((err)=>{
        res.status(500).json({ message: 'Error in deleting data' });
    })
}
const updateData = (req,res) =>{
    const id = req.params.id;
    const name = req.body.name;
    const address = req.body.address;
    const data = {name,address};
    dao.updateData(id,data)
    .then((response)=>{
        res.status(200).send(response);
    })
    .catch((err)=>{
        res.status(500).json({ message: 'Error in updating data' });
    })
}
module.exports={getAllData,getDataById,insertData,deleteData,updateData};