const express = require('express');
const router = express.Router();

const controller = require("../ccontroller/controller");

router.get('/data',controller.getAllData);
router.get('/data/:id',controller.getDataById);
router.post('/data',controller.insertData);
router.delete('/data/:id',controller.deleteData);
router.put('/data/:id',controller.updateData);
module.exports = router;