const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (CSS, JS, etc.)
app.use(express.static("public"));

// Route to display the first form (/form)
app.get("/form", (req, res) => {
    res.send(`
        <h1>Customer Input Form</h1>
        <form action="/submit" method="post">
            <label for="customerId">Customer ID:</label>
            <input type="text" id="customerId" name="customerId" required><br>
            
            <label for="customerName">Customer Name:</label>
            <input type="text" id="customerName" name="customerName" required><br>
            
            <label for="phoneNo">Phone Number:</label>
          <input type="text" id="phoneNo" name="phoneNo" pattern="[0-9]{10}" title="Enter a 10-digit phone number" required>


            
            <button type="submit">Submit</button>
        </form>
    `);
});

// Route to handle form submission (/submit)
app.post("/submit", (req, res) => {
    const { customerId, customerName, phoneNo } = req.body;
    
    if (!customerId || !customerName || !phoneNo.match(/^\d{10}$/)) {
        return res.send("<h3>Error: Invalid input. Phone number must be 10 digits.</h3>");
    }
    
    console.log("Form Data:", req.body);
    res.send(`
        <h3>Form submitted successfully!</h3>
        <p><strong>Customer ID:</strong> ${customerId}</p>
        <p><strong>Customer Name:</strong> ${customerName}</p>
        <p><strong>Phone Number:</strong> ${phoneNo}</p>
    `);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
