import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const StudentCrud = () => {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ rollno: "", name: "", phone: "", state: "" });
  const [editIndex, setEditIndex] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editIndex !== null) {
      const updatedStudents = [...students];
      updatedStudents[editIndex] = form;
      setStudents(updatedStudents);
      setEditIndex(null);
    } else {
      setStudents([...students, form]);
    }
    setForm({ rollno: "", name: "", phone: "", state: "" });
  };

  const handleEdit = (index) => {
    setForm(students[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    setStudents(students.filter((_, i) => i !== index));
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Student Management</h2>
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="mb-3">
          <input type="text" className="form-control" name="rollno" value={form.rollno} onChange={handleChange} placeholder="Roll No" required />
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" name="name" value={form.name} onChange={handleChange} placeholder="Name" required />
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" name="phone" value={form.phone} onChange={handleChange} placeholder="Phone" required />
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" name="state" value={form.state} onChange={handleChange} placeholder="State" required />
        </div>
        <button type="submit" className="btn btn-primary">{editIndex !== null ? "Update" : "Add"} Student</button>
      </form>
      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>Roll No</th>
            <th>Name</th>
            <th>Phone</th>
            <th>State</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.rollno}</td>
              <td>{student.name}</td>
              <td>{student.phone}</td>
              <td>{student.state}</td>
              <td>
                <button onClick={() => handleEdit(index)} className="btn btn-warning me-2">Edit</button>
                <button onClick={() => handleDelete(index)} className="btn btn-danger">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentCrud;
