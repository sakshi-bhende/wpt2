import './App.css';
import StudentCrud from './StudentCrud';
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
  return (
    <div className="App">
      <StudentCrud/>
    </div>
  );
}

export default App;
