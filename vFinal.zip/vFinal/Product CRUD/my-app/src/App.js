import logo from './logo.svg';
import './App.css';
import ProductCrudApp from './component/ProductCrudApp';

function App() {
  return (
    <div className="App">
     <ProductCrudApp />
    </div>
  );
}

export default App;
